import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],

  server: {
    proxy: {
      "/api": {
        target: "http://localhost:8080",
        changeOrigin: true,
      },

      "/currency": {
        target: "https://bankofgeorgia.ge",
        changeOrigin: true,
        secure: true,
        rewrite: (path) => path.replace(/^\/currency/, "/api"),
      },
    },
  },
});
