export const convertCurrency = async (fromCurrency, toCurrency, amount) => {
  const url = `/currency/currencies/convert/${fromCurrency}/${toCurrency}?amountFrom=${amount}`;

  console.log("========== CURRENCY REQUEST ==========");
  console.log("URL:", url);
  console.log("FROM:", fromCurrency);
  console.log("TO:", toCurrency);
  console.log("AMOUNT:", amount);

  try {
    const response = await fetch(url);

    console.log("========== AFTER FETCH ==========");
    console.log("STATUS:", response.status);
    console.log("OK:", response.ok);
    console.log("TYPE:", response.type);

    const data = await response.json();

    console.log("========== RESPONSE ==========");
    console.log(data);
    console.log("AMOUNT:", data?.data?.amount);
    console.log("RATE:", data?.data?.rate);

    if (!response.ok) {
      throw new Error("Currency conversion failed");
    }

    return {
      amount: Number(data.data.amount),
      rate: Number(data.data.rate),
    };
  } catch (error) {
    console.error("FETCH ERROR:", error);
    throw error;
  }
};
