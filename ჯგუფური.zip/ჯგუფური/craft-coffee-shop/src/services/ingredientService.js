const INGREDIENTS_URL = "/api/v1/resource/ingredients";

const headers = {
  "Content-Type": "application/json",
  "x-bypass-token": import.meta.env.VITE_BYPASS_TOKEN,
};

export const getIngredients = async () => {
  const response = await fetch(INGREDIENTS_URL, {
    method: "GET",
    headers,
  });

  if (!response.ok) {
    throw new Error("Failed to fetch ingredients");
  }

  const data = await response.json();

  return data;
};

export const getIngredientById = async (id) => {
  const response = await fetch(`${INGREDIENTS_URL}/${id}`, {
    method: "GET",
    headers,
  });

  if (!response.ok) {
    throw new Error("Failed to fetch ingredient");
  }

  const data = await response.json();

  return data;
};
