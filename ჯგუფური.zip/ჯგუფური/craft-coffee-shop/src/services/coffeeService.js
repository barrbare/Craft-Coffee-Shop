const COFFEES_URL = "/api/v1/resource/coffees";

const headers = {
  "Content-Type": "application/json",
  "x-bypass-token": import.meta.env.VITE_BYPASS_TOKEN,
};

export const getCoffees = async () => {
  const response = await fetch(COFFEES_URL, {
    method: "GET",
    headers,
  });

  if (!response.ok) {
    throw new Error("Failed to fetch coffees");
  }

  const data = await response.json();

  return data;
};

export const getCoffeeById = async (id) => {
  const response = await fetch(`${COFFEES_URL}/${id}`, {
    method: "GET",
    headers,
  });

  if (!response.ok) {
    throw new Error("Failed to fetch coffee");
  }

  const data = await response.json();

  return data;
};

export const createCoffee = async (coffee) => {
  const response = await fetch(COFFEES_URL, {
    method: "POST",
    headers,
    body: JSON.stringify({
      data: [coffee],
    }),
  });

  if (!response.ok) {
    throw new Error("Failed to create coffee");
  }

  return response.json();
};

export const updateCoffee = async (coffee) => {
  const response = await fetch(`${COFFEES_URL}/${coffee.id}`, {
    method: "PUT",
    headers,
    body: JSON.stringify({
      data: {
        title: coffee.title,
        ingredients: coffee.ingredients,
        description: coffee.description,
        image: coffee.image,
        country: coffee.country,
        caffeine: coffee.caffeine,
      },
    }),
  });

  if (!response.ok) {
    throw new Error("Failed to update coffee");
  }

  return response.json();
};

export const deleteCoffee = async (id) => {
  const response = await fetch(`${COFFEES_URL}/${id}`, {
    method: "DELETE",
    headers,
  });

  if (!response.ok) {
    throw new Error("Failed to delete coffee");
  }

  return response.json();
};
