import { createBrowserRouter } from "react-router-dom";

import MainLayout from "../layouts/MainLayout";

import HomePage from "../pages/HomePage";
import CoffeeListPage from "../pages/CoffeeListPage";
import CoffeeDetailsPage from "../pages/CoffeeDetailsPage";
import IngredientListPage from "../pages/IngredientListPage";
import IngredientDetailsPage from "../pages/IngredientDetailsPage";

const routes = createBrowserRouter([
  {
    path: "/",
    element: <MainLayout />,
    children: [
      {
        index: true,
        element: <HomePage />,
      },
      {
        path: "coffees",
        element: <CoffeeListPage />,
      },
      {
        path: "coffees/:id",
        element: <CoffeeDetailsPage />,
      },
      {
        path: "ingredients",
        element: <IngredientListPage />,
      },
      {
        path: "ingredients/:id",
        element: <IngredientDetailsPage />,
      },
    ],
  },
]);

export default routes;
