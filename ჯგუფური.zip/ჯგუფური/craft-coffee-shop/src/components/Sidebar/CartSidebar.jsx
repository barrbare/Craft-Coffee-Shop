import Cart from "../Cart/Cart";

import { Overlay, Sidebar, CloseButton } from "./CartSidebar.styles";

const CartSidebar = ({ isOpen, onClose }) => {
  return (
    <>
      <Overlay $isOpen={isOpen} onClick={onClose} />

      <Sidebar $isOpen={isOpen}>
        <CloseButton onClick={onClose}>✕</CloseButton>

        <Cart />
      </Sidebar>
    </>
  );
};

export default CartSidebar;
