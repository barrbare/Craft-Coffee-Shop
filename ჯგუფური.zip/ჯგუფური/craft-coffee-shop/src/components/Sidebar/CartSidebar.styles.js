import styled from "styled-components";

const HEADER_HEIGHT = 96;

export const Overlay = styled("div")(({ $isOpen }) => ({
  position: "fixed",
  top: `${HEADER_HEIGHT}px`,
  left: 0,
  right: 0,
  bottom: 0,

  backgroundColor: "rgba(35, 20, 15, 0.35)",

  opacity: $isOpen ? 1 : 0,
  visibility: $isOpen ? "visible" : "hidden",

  transition: "opacity .3s ease",

  zIndex: 998,
}));

export const Sidebar = styled("aside")(({ $isOpen }) => ({
  position: "fixed",

  top: `${HEADER_HEIGHT}px`,
  right: 0,

  /* უფრო ბუნებრივი სიგანე */
  width: "32vw",
  minWidth: "340px",
  maxWidth: "420px",

  height: `calc(100vh - ${HEADER_HEIGHT}px)`,

  background: "#E8D2B8",

  borderLeft: "2px solid #A06B3B",

  boxShadow: "-14px 0 35px rgba(35,20,15,.25)",

  transform: $isOpen ? "translateX(0)" : "translateX(100%)",

  transition: "transform .35s ease",

  overflowY: "auto",

  padding: "26px 24px",

  zIndex: 999,
}));

export const CloseButton = styled("button")({
  width: "42px",
  height: "42px",

  marginLeft: "auto",
  marginBottom: "24px",

  display: "flex",
  justifyContent: "center",
  alignItems: "center",

  border: "none",
  borderRadius: "50%",

  background: "transparent",

  cursor: "pointer",

  color: "#2f1b14",

  fontSize: "34px",

  transition: ".2s",

  "&:hover": {
    backgroundColor: "#CDA06E",
    color: "#fff",
  },
});
