import styled from "styled-components";

export const PageContainer = styled("section")({
  maxWidth: "1100px",
  margin: "0 auto",
  padding: "60px 40px 80px",
});

export const IngredientName = styled("h1")({
  margin: "0 0 60px",
  textAlign: "center",
  fontSize: "64px",
  fontWeight: "700",
  color: "#2f1b14",
  lineHeight: "1.1",
});

export const Content = styled("div")({
  display: "flex",
  justifyContent: "center",
  marginBottom: "70px",
});

export const Info = styled("div")({
  display: "flex",
  flexDirection: "column",
  alignItems: "flex-start",
  gap: "24px",
});

export const Label = styled("p")({
  margin: 0,
  fontSize: "24px",
  lineHeight: "1.6",
  color: "#2f1b14",
});

export const BottomRow = styled("div")({
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  gap: "140px",
  marginTop: "20px",
});

export const Price = styled("h2")({
  margin: 0,
  fontSize: "52px",
  fontWeight: "700",
  color: "#2f1b14",
});

export const ButtonsGroup = styled("div")({
  display: "flex",
  gap: "20px",
});
