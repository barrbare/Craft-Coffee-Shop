import Button from "../Button/Button";

import {
  PageContainer,
  IngredientName,
  Content,
  Info,
  Label,
  Price,
  BottomRow,
  ButtonsGroup,
} from "./IngredientDetailsCard.styles";

const IngredientDetailsCard = ({ ingredient, onAdd, onBack }) => {
  return (
    <PageContainer>
      <IngredientName>{ingredient.data.name}</IngredientName>

      <Content>
        <Info>
          <Label>
            <strong>Description:</strong> {ingredient.data.description}
          </Label>

          <Label>
            <strong>Strength:</strong> {ingredient.data.strength}
          </Label>

          <Label>
            <strong>Flavor:</strong> {ingredient.data.flavor}
          </Label>
        </Info>
      </Content>

      <BottomRow>
        <Price>{ingredient.data.price} ₾</Price>

        <ButtonsGroup>
          <Button onClick={onAdd}>Add</Button>

          <Button onClick={onBack}>Back to Ingredients</Button>
        </ButtonsGroup>
      </BottomRow>
    </PageContainer>
  );
};

export default IngredientDetailsCard;
