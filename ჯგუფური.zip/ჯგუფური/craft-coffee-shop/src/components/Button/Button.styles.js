import styled from "styled-components";

export const StyledButton = styled("button")(({ $size }) => ({
  padding: $size === "small" ? "14px 24px" : "16px 32px",

  backgroundColor: "#d4a373",

  color: "#ffffff",

  border: "none",

  borderRadius: "8px",

  fontSize: $size === "small" ? "16px" : "18px",

  fontWeight: "600",

  cursor: "pointer",

  transition: "all 0.3s ease",

  "&:hover": {
    backgroundColor: "#b88652",
  },
}));
