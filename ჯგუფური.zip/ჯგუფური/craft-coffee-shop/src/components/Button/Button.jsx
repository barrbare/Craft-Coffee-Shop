import { StyledButton } from "./Button.styles";

const Button = ({ children, size = "default", ...props }) => {
  return (
    <StyledButton $size={size} {...props}>
      {children}
    </StyledButton>
  );
};

export default Button;
