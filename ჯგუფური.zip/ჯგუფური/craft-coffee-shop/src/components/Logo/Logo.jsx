import { LogoLink } from "./Logo.styles";

const Logo = () => {
  return <LogoLink to="/">Craft Coffee</LogoLink>;
};

export default Logo;
