import styled from "styled-components";
import { Link } from "react-router-dom";

export const LogoLink = styled(Link)({
  textDecoration: "none",

  color: "#d4a373",

  fontSize: "36px",
  fontWeight: "700",
  fontFamily: "Georgia, serif",
  letterSpacing: "0.5px",

  transition: "color 0.25s ease",

  "&:hover": {
    color: "#f5e6d3",
  },
});
