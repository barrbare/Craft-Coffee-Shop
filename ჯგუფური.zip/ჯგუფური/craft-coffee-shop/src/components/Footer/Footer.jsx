import {
  FooterContainer,
  FooterContent,
  FooterLeft,
  FooterTitle,
  FooterQuote,
  FooterRight,
  NavigationTitle,
  NavigationList,
  NavigationItem,
  FooterLink,
  FooterBottom,
} from "./Footer.styles";

const Footer = () => {
  return (
    <FooterContainer>
      <FooterContent>
        <FooterLeft>
          <FooterTitle>Craft Coffee</FooterTitle>

          <FooterQuote>"Every cup tells a story."</FooterQuote>
        </FooterLeft>

        <FooterRight>
          <NavigationTitle>Navigation</NavigationTitle>

          <NavigationList>
            <NavigationItem>
              <FooterLink to="/">Home</FooterLink>
            </NavigationItem>

            <NavigationItem>
              <FooterLink to="/coffees">Coffees</FooterLink>
            </NavigationItem>

            <NavigationItem>
              <FooterLink to="/ingredients">Ingredients</FooterLink>
            </NavigationItem>
          </NavigationList>
        </FooterRight>
      </FooterContent>

      <FooterBottom>© 2026 Craft Coffee. All rights reserved.</FooterBottom>
    </FooterContainer>
  );
};

export default Footer;
