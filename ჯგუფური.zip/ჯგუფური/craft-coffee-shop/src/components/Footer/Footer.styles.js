import styled from "styled-components";
import { Link } from "react-router-dom";

export const FooterContainer = styled("footer")({
  backgroundColor: "#3B2218",
  color: "#E8D2B8",

  marginTop: "80px",
  padding: "60px 40px 25px",
});

export const FooterContent = styled("div")({
  maxWidth: "1200px",

  margin: "0 auto",

  display: "flex",
  justifyContent: "space-between",
  alignItems: "flex-start",

  gap: "80px",
});

export const FooterLeft = styled("div")({
  display: "flex",
  flexDirection: "column",

  gap: "18px",
});

export const FooterTitle = styled("h2")({
  margin: 0,

  fontSize: "42px",

  fontWeight: "700",

  color: "#E8D2B8",
});

export const FooterQuote = styled("p")({
  margin: 0,

  fontSize: "22px",

  fontStyle: "italic",

  color: "#D8C0A5",

  lineHeight: "1.6",
});

export const FooterRight = styled("div")({
  display: "flex",
  flexDirection: "column",

  gap: "20px",
});

export const NavigationTitle = styled("h3")({
  margin: 0,

  fontSize: "28px",

  color: "#E8D2B8",
});

export const NavigationList = styled("ul")({
  listStyle: "none",

  padding: 0,
  margin: 0,

  display: "flex",
  flexDirection: "column",

  gap: "14px",
});

export const NavigationItem = styled("li")({});

export const FooterLink = styled(Link)({
  textDecoration: "none",

  color: "#E8D2B8",

  fontSize: "20px",

  transition: "0.3s",

  "&:hover": {
    color: "#C58B5A",
  },
});

export const FooterBottom = styled("div")({
  marginTop: "50px",
  paddingTop: "20px",

  borderTop: "1px solid rgba(232,210,184,0.25)",

  textAlign: "center",

  fontSize: "18px",

  color: "#CDB49A",
});
