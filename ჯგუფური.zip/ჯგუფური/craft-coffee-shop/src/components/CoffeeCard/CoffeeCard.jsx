import { useNavigate } from "react-router-dom";

import Button from "../Button/Button";

import {
  CardContainer,
  CardImage,
  CardContent,
  CoffeeTitle,
  CoffeeCountry,
  CoffeeDescription,
} from "./CoffeeCard.styles";

const CoffeeCard = ({ coffee }) => {
  const navigate = useNavigate();

  return (
    <CardContainer>
      <CardImage src={coffee.data.image} alt={coffee.data.title} />

      <CardContent>
        <CoffeeTitle>{coffee.data.title}</CoffeeTitle>

        <CoffeeCountry>{coffee.data.country}</CoffeeCountry>

        <CoffeeDescription>{coffee.data.description}</CoffeeDescription>

        <Button onClick={() => navigate(`/coffees/${coffee.id}`)}>
          View Details
        </Button>
      </CardContent>
    </CardContainer>
  );
};

export default CoffeeCard;
