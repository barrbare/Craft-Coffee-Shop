import styled from "styled-components";

export const CardContainer = styled("article")({
  width: "320px",

  borderRadius: "16px",

  overflow: "hidden",

  backgroundColor: "#E8D2B8",

  boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)",
});

export const CardImage = styled("img")({
  width: "100%",

  height: "220px",

  objectFit: "cover",

  display: "block",
});

export const CardContent = styled("div")({
  padding: "24px",
});

export const CoffeeTitle = styled("h3")({
  fontSize: "28px",

  color: "#2f1b14",

  marginBottom: "12px",
});

export const CoffeeCountry = styled("p")({
  color: "#d4a373",

  fontWeight: "600",

  marginBottom: "12px",
});

export const CoffeeDescription = styled("p")({
  color: "#5c4033",

  lineHeight: "1.6",

  marginBottom: "24px",
});
