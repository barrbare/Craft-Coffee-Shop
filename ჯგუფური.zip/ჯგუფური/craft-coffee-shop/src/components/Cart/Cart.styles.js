import styled from "styled-components";

export const CartContainer = styled("div")({
  display: "flex",
  flexDirection: "column",
});

export const CartTitle = styled("h2")({
  margin: "0 0 24px",
  fontSize: "42px",
  color: "#2f1b14",
});

export const CartItem = styled("div")({
  paddingBottom: "18px",
  marginBottom: "18px",
  borderBottom: "1px solid rgba(47,27,20,.2)",
});

export const CoffeeName = styled("h3")({
  margin: "0 0 8px",
  fontSize: "30px",
  color: "#2f1b14",
});

export const CartText = styled("p")({
  margin: "4px 0",
  fontSize: "20px",
  color: "#2f1b14",
});

export const ButtonWrapper = styled("div")({
  marginTop: "16px",
});

export const GrandTotal = styled("div")({
  marginTop: "10px",
  paddingTop: "18px",

  borderTop: "2px solid #B9956C",

  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",

  fontSize: "28px",
  fontWeight: "700",
  color: "#2f1b14",
});
