import { useContext } from "react";

import Button from "../Button/Button";
import { CoffeeShopContext } from "../../context/CoffeeShopContext";
import { CurrencyContext } from "../../context/CurrencyContext";

import {
  CartContainer,
  CartTitle,
  CartItem,
  CoffeeName,
  CartText,
  ButtonWrapper,
  GrandTotal,
} from "./Cart.styles";

const Cart = () => {
  const { cart, removeCoffee, calculateTotalPrice } =
    useContext(CoffeeShopContext);

  const { formatPrice } = useContext(CurrencyContext);

  const grandTotal = cart.reduce(
    (sum, item) => sum + calculateTotalPrice(item),
    0,
  );

  return (
    <CartContainer>
      <CartTitle>Cart</CartTitle>

      {cart.length === 0 ? (
        <CartText>Your cart is empty.</CartText>
      ) : (
        <>
          {cart.map((item) => (
            <CartItem key={item.coffee.id}>
              <CoffeeName>{item.coffee.data.title}</CoffeeName>

              <CartText>Quantity: {item.quantity}</CartText>

              <CartText>
                Total: {formatPrice(calculateTotalPrice(item))}
              </CartText>

              <ButtonWrapper>
                <Button onClick={() => removeCoffee(item.coffee.id)}>
                  Remove
                </Button>
              </ButtonWrapper>
            </CartItem>
          ))}

          <GrandTotal>
            <span>Grand Total</span>
            <span>{formatPrice(grandTotal)}</span>
          </GrandTotal>
        </>
      )}
    </CartContainer>
  );
};

export default Cart;
