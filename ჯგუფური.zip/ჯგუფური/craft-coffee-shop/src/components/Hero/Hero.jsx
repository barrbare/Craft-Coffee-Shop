import Button from "../Button/Button";

import {
  HeroContainer,
  HeroContent,
  HeroTitle,
  HeroDescription,
} from "./Hero.styles";

const Hero = () => {
  const handleExploreClick = () => {
    const coffeeSection = document.getElementById("coffees");

    if (coffeeSection) {
      coffeeSection.scrollIntoView({
        behavior: "smooth",
        block: "start",
      });
    }
  };

  return (
    <HeroContainer>
      <HeroContent>
        <HeroTitle>
          Crafted Coffee,
          <br />
          Perfected Moments
        </HeroTitle>

        <HeroDescription>
          Discover handcrafted coffee,
          <br />
          brewed with passion.
        </HeroDescription>

        <Button onClick={handleExploreClick}>Explore Coffees</Button>
      </HeroContent>
    </HeroContainer>
  );
};

export default Hero;
