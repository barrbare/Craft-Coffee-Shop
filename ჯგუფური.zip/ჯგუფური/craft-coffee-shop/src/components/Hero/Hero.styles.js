import styled from "styled-components";

import heroBackground from "../../assets/images/hero-background.png";

export const HeroContainer = styled("section")({
  position: "relative",

  display: "flex",
  justifyContent: "center",
  alignItems: "center",

  width: "100%",
  height: "100vh",

  backgroundImage: `url(${heroBackground})`,
  backgroundSize: "cover",
  backgroundPosition: "center",
  backgroundRepeat: "no-repeat",

  "&::before": {
    content: '""',

    position: "absolute",
    inset: 0,

    background: "rgba(30, 18, 10, 0.55)",
  },
});

export const HeroContent = styled("div")({
  position: "relative",
  zIndex: 1,

  width: "100%",
  maxWidth: "1200px",

  padding: "0 32px",

  textAlign: "center",
});

export const HeroTitle = styled("h1")({
  fontSize: "clamp(72px, 7vw, 110px)",
  fontWeight: "700",
  lineHeight: "1.05",
  letterSpacing: "-2px",

  color: "#ffffff",

  marginBottom: "36px",
});

export const HeroDescription = styled("p")({
  maxWidth: "900px",

  margin: "0 auto 52px",

  fontSize: "clamp(24px, 2vw, 30px)",
  lineHeight: "1.6",

  color: "#f5f5f5",
});
