import { useContext } from "react";
import { FaDollarSign } from "react-icons/fa";
import { HiShoppingCart } from "react-icons/hi2";

import Logo from "../Logo/Logo";
import Navigation from "../Navigation/Navigation";

import { CurrencyContext } from "../../context/CurrencyContext";
import { CoffeeShopContext } from "../../context/CoffeeShopContext";

import {
  HeaderContainer,
  HeaderRight,
  HeaderAction,
  CartIconWrapper,
  CartBadge,
} from "./Header.styles";

const Header = ({ onCartClick, showHeader }) => {
  const { toggleCurrency } = useContext(CurrencyContext);
  const { cart } = useContext(CoffeeShopContext);

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <HeaderContainer $visible={showHeader}>
      <Logo />

      <HeaderRight>
        <Navigation />

        <HeaderAction onClick={toggleCurrency}>
          <FaDollarSign />
        </HeaderAction>

        <HeaderAction onClick={onCartClick}>
          <CartIconWrapper>
            <HiShoppingCart />

            {cartCount > 0 && <CartBadge>{cartCount}</CartBadge>}
          </CartIconWrapper>
        </HeaderAction>
      </HeaderRight>
    </HeaderContainer>
  );
};

export default Header;
