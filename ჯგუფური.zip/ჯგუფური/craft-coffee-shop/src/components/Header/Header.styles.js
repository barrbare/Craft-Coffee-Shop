import styled from "styled-components";

export const HEADER_HEIGHT = 96;

export const HeaderContainer = styled("header")(({ $visible }) => ({
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",

  height: `${HEADER_HEIGHT}px`,
  padding: "0 40px",

  backgroundColor: "#2f1b14",

  position: "fixed",
  top: 0,
  left: 0,
  right: 0,

  zIndex: 1000,

  transform: $visible ? "translateY(0)" : "translateY(-100%)",

  opacity: $visible ? 1 : 0,

  transition: "transform 0.45s ease, opacity 0.45s ease",

  pointerEvents: $visible ? "auto" : "none",
}));

export const HeaderRight = styled("div")({
  display: "flex",
  alignItems: "center",
  gap: "36px",
});

export const HeaderAction = styled("button")({
  display: "flex",
  alignItems: "center",
  justifyContent: "center",

  padding: 0,

  border: "none",
  outline: "none",

  background: "transparent",

  color: "#f5e6d3",

  cursor: "pointer",

  transition: "all 0.25s ease",

  "&:hover": {
    color: "#d4a373",
    transform: "translateY(-1px)",
  },

  "& svg": {
    fontSize: "24px",
    flexShrink: 0,
  },
});

export const CartIconWrapper = styled("div")({
  position: "relative",

  display: "flex",
  alignItems: "center",
  justifyContent: "center",
});

export const CartBadge = styled("span")({
  position: "absolute",

  top: "48%",
  left: "50%",

  transform: "translate(-50%, -50%)",

  fontSize: "9px",
  fontWeight: "700",
  lineHeight: 1,

  color: "#2f1b14",

  pointerEvents: "none",
  userSelect: "none",
});
