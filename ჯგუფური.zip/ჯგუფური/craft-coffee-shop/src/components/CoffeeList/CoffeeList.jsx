import { useContext, useEffect } from "react";

import CoffeeCard from "../CoffeeCard/CoffeeCard";
import { CoffeeContext } from "../../context/CoffeeContext";
import {
  CoffeeListSection,
  CoffeeListTitle,
  CoffeeListContainer,
} from "./CoffeeList.styles";

const CoffeeList = () => {
  const { coffees, fetchCoffees } = useContext(CoffeeContext);

  useEffect(() => {
    fetchCoffees();
  }, []);

  return (
    <CoffeeListSection id="coffees">
      <CoffeeListTitle>Discover Our Coffee Collection</CoffeeListTitle>

      <CoffeeListContainer>
        {coffees.map((coffee) => (
          <CoffeeCard key={coffee.id} coffee={coffee} />
        ))}
      </CoffeeListContainer>
    </CoffeeListSection>
  );
};

export default CoffeeList;
