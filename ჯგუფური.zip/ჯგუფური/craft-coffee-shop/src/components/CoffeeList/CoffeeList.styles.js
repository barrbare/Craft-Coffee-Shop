import styled from "styled-components";

export const CoffeeListSection = styled("section")({
  padding: "55px 20px 40px",

  background: "transparent",
});

export const CoffeeListTitle = styled("h2")({
  margin: "0 0 40px",

  textAlign: "center",

  fontSize: "48px",

  fontWeight: "700",

  lineHeight: "1.2",

  color: "#2f1b14",
});

export const CoffeeListContainer = styled("div")({
  display: "grid",

  gridTemplateColumns: "repeat(3, 320px)",

  gap: "40px",

  justifyContent: "center",
});
