import styled from "styled-components";

export const PageContainer = styled("section")({
  width: "100%",
  padding: "60px 30px 70px",
});

export const Content = styled("div")({
  display: "flex",
  justifyContent: "center",
  alignItems: "flex-start",
  gap: "45px",

  width: "fit-content",
  margin: "0 auto",
});

export const CoffeeImage = styled("img")({
  width: "420px",
  height: "420px",

  objectFit: "cover",

  borderRadius: "18px",

  boxShadow: "0 8px 20px rgba(0,0,0,0.15)",
});

export const Info = styled("div")({
  width: "360px",

  display: "flex",
  flexDirection: "column",

  gap: "18px",
});

export const CoffeeTitle = styled("h1")({
  margin: 0,

  fontSize: "52px",

  lineHeight: "1.1",

  color: "#2F1B14",
});

export const Text = styled("p")({
  margin: 0,

  fontSize: "22px",

  lineHeight: "1.5",

  color: "#2F1B14",
});

export const IngredientsTitle = styled("h3")({
  margin: "8px 0 0",

  fontSize: "30px",

  color: "#2F1B14",
});

export const IngredientsList = styled("ul")({
  margin: 0,

  paddingLeft: "24px",

  fontSize: "22px",

  lineHeight: "1.6",

  color: "#2F1B14",
});

export const ButtonsContainer = styled("div")({
  display: "flex",

  justifyContent: "center",

  gap: "20px",

  marginTop: "40px",
});

// ==========================
// NEW
// ==========================

export const BottomRow = styled("div")({
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  marginTop: "45px",
});

export const Price = styled("h2")({
  margin: 0,
  fontSize: "52px",
  fontWeight: "700",
  color: "#2F1B14",
});

export const ButtonsGroup = styled("div")({
  display: "flex",
  gap: "20px",
});
