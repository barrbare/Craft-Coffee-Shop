import Button from "../Button/Button";

import {
  PageContainer,
  Content,
  CoffeeImage,
  Info,
  CoffeeTitle,
  Text,
  IngredientsTitle,
  IngredientsList,
  ButtonsContainer,
} from "./CoffeeDetails.styles";

const CoffeeDetailsCard = ({
  coffee,
  coffeeIngredients,
  currency,
  convertedPrices,
  onBuy,
  onBack,
}) => {
  return (
    <PageContainer>
      <Content>
        <CoffeeImage src={coffee.data.image} alt={coffee.data.title} />

        <Info>
          <CoffeeTitle>{coffee.data.title}</CoffeeTitle>

          <Text>
            <strong>Country:</strong> {coffee.data.country}
          </Text>

          <Text>
            <strong>Description:</strong> {coffee.data.description}
          </Text>

          <IngredientsTitle>Ingredients</IngredientsTitle>

          <IngredientsList>
            {coffeeIngredients.map((ingredient) => (
              <li key={ingredient.id}>
                {ingredient.data.name} —{" "}
                {currency === "GEL"
                  ? `${ingredient.data.price} ₾`
                  : `${Number(convertedPrices[ingredient.id] || 0).toFixed(
                      2,
                    )} $`}
              </li>
            ))}
          </IngredientsList>

          <Text>
            <strong>Caffeine:</strong> {coffee.data.caffeine ?? "Not specified"}
          </Text>
        </Info>
      </Content>

      <ButtonsContainer>
        <Button onClick={onBuy}>Buy</Button>

        <Button onClick={onBack}>Back to Coffees</Button>
      </ButtonsContainer>
    </PageContainer>
  );
};

export default CoffeeDetailsCard;
