import { useContext } from "react";
import { useNavigate } from "react-router-dom";

import Button from "../Button/Button";

import { CurrencyContext } from "../../context/CurrencyContext";

import {
  Card,
  IngredientName,
  Label,
  ButtonContainer,
  BottomRow,
  Price,
} from "./IngredientCard.styles";

const IngredientCard = ({ ingredient }) => {
  const navigate = useNavigate();

  const { formatPrice } = useContext(CurrencyContext);

  return (
    <Card>
      <div>
        <IngredientName>{ingredient.data.name}</IngredientName>

        <Label>
          <strong>Description:</strong> {ingredient.data.description}
        </Label>

        <Label>
          <strong>Strength:</strong> {ingredient.data.strength}
        </Label>

        <Label>
          <strong>Flavor:</strong> {ingredient.data.flavor}
        </Label>
      </div>

      <BottomRow>
        <Price>{formatPrice(ingredient.data.price)}</Price>

        <ButtonContainer>
          <Button onClick={() => navigate(`/ingredients/${ingredient.id}`)}>
            Details
          </Button>
        </ButtonContainer>
      </BottomRow>
    </Card>
  );
};

export default IngredientCard;
