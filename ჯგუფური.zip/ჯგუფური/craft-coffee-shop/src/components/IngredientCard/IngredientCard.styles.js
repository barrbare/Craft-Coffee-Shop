import styled from "styled-components";

export const Card = styled("div")({
  background: "#E8D2B8",

  borderRadius: "24px",

  padding: "32px",

  boxShadow: "0 10px 30px rgba(0, 0, 0, 0.08)",

  display: "flex",

  flexDirection: "column",

  justifyContent: "space-between",

  minHeight: "320px",

  transition: "0.3s ease",
});

export const IngredientName = styled("h3")({
  margin: "0 0 24px",

  fontSize: "40px",

  fontWeight: "700",

  color: "#2f1b14",
});

export const Label = styled("p")({
  margin: "10px 0",

  fontSize: "20px",

  color: "#2f1b14",

  lineHeight: "1.6",
});

export const BottomRow = styled("div")({
  display: "flex",

  justifyContent: "space-between",

  alignItems: "center",

  marginTop: "32px",
});

export const Price = styled("span")({
  fontSize: "28px",

  fontWeight: "700",

  color: "#2f1b14",
});

export const ButtonContainer = styled("div")({
  display: "flex",

  marginRight: "20px",
});
