import { NavigationContainer, NavigationLink } from "./Navigation.styles";

const Navigation = () => {
  return (
    <NavigationContainer>
      <NavigationLink to="/">Home</NavigationLink>

      <NavigationLink to="/coffees">Coffees</NavigationLink>

      <NavigationLink to="/ingredients">Ingredients</NavigationLink>
    </NavigationContainer>
  );
};

export default Navigation;
