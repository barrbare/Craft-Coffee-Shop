import styled from "styled-components";
import { NavLink } from "react-router-dom";

export const NavigationContainer = styled("nav")({
  display: "flex",
  gap: "32px",
  alignItems: "center",
});

export const NavigationLink = styled(NavLink)({
  textDecoration: "none",

  color: "#d4a373",

  fontSize: "18px",
  fontWeight: "600",

  transition: "color 0.25s ease",

  "&:hover": {
    color: "#f5e6d3",
  },

  "&.active": {
    color: "#f5e6d3",
  },
});
