import { StrictMode } from "react";
import { createRoot } from "react-dom/client";

import "./index.css";
import App from "./App";

import CoffeeProvider from "./context/CoffeeContext";
import IngredientProvider from "./context/IngredientContext";
import CoffeeShopProvider from "./context/CoffeeShopContext";
import CurrencyProvider from "./context/CurrencyContext";

createRoot(document.getElementById("root")).render(
  <StrictMode>
    <CoffeeProvider>
      <IngredientProvider>
        <CoffeeShopProvider>
          <CurrencyProvider>
            <App />
          </CurrencyProvider>
        </CoffeeShopProvider>
      </IngredientProvider>
    </CoffeeProvider>
  </StrictMode>,
);
