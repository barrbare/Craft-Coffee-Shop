import { createContext, useState } from "react";

import {
  getIngredients,
  getIngredientById,
} from "../services/ingredientService";

export const IngredientContext = createContext();

const IngredientProvider = ({ children }) => {
  const [ingredients, setIngredients] = useState([]);

  const fetchIngredients = async () => {
    const response = await getIngredients();

    setIngredients(response || []);
  };

  const fetchIngredientById = async (id) => {
    return await getIngredientById(id);
  };

  return (
    <IngredientContext.Provider
      value={{
        ingredients,
        fetchIngredients,
        fetchIngredientById,
      }}
    >
      {children}
    </IngredientContext.Provider>
  );
};

export default IngredientProvider;
