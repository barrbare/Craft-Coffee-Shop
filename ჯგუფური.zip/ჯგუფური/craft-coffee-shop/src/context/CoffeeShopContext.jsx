import { createContext, useState } from "react";

export const CoffeeShopContext = createContext();

const CoffeeShopProvider = ({ children }) => {
  const [cart, setCart] = useState([]);
  const [selectedCoffeeId, setSelectedCoffeeId] = useState(null);

  // ==========================
  // Buy Coffee
  // ==========================

  const buyCoffee = (coffee, defaultIngredients) => {
    console.log("========== BUY CLICKED ==========");
    console.log("Coffee:", coffee);
    console.log("Default Ingredients:", defaultIngredients);

    setSelectedCoffeeId(coffee.id);

    setCart((prevCart) => {
      console.log("Previous Cart:", prevCart);

      const existingCoffee = prevCart.find(
        (item) => item.coffee.id === coffee.id,
      );

      if (existingCoffee) {
        console.log("Coffee already exists -> increasing quantity");

        return prevCart.map((item) =>
          item.coffee.id === coffee.id
            ? {
                ...item,
                quantity: item.quantity + 1,
              }
            : item,
        );
      }

      console.log("Adding new coffee to cart");

      return [
        ...prevCart,
        {
          coffee,
          defaultIngredients,
          quantity: 1,
          extraIngredients: [],
        },
      ];
    });
  };

  // ==========================
  // Remove Coffee
  // ==========================

  const removeCoffee = (coffeeId) => {
    setCart((prevCart) =>
      prevCart
        .map((item) =>
          item.coffee.id === coffeeId
            ? {
                ...item,
                quantity: item.quantity - 1,
              }
            : item,
        )
        .filter((item) => item.quantity > 0),
    );
  };

  // ==========================
  // Clear Cart
  // ==========================

  const clearCart = () => {
    setCart([]);
    setSelectedCoffeeId(null);
  };

  // ==========================
  // Add Ingredient
  // ==========================

  const addIngredient = (ingredient) => {
    if (!selectedCoffeeId) return;

    setCart((prevCart) =>
      prevCart.map((item) => {
        if (item.coffee.id !== selectedCoffeeId) {
          return item;
        }

        const existingIngredient = item.extraIngredients.find(
          (extra) => extra.id === ingredient.id,
        );

        if (existingIngredient) {
          return {
            ...item,
            extraIngredients: item.extraIngredients.map((extra) =>
              extra.id === ingredient.id
                ? {
                    ...extra,
                    quantity: extra.quantity + 1,
                  }
                : extra,
            ),
          };
        }

        return {
          ...item,
          extraIngredients: [
            ...item.extraIngredients,
            {
              ...ingredient,
              quantity: 1,
            },
          ],
        };
      }),
    );
  };

  // ==========================
  // Remove Ingredient
  // ==========================

  const removeIngredient = (ingredientId) => {
    if (!selectedCoffeeId) return;

    setCart((prevCart) =>
      prevCart.map((item) => {
        if (item.coffee.id !== selectedCoffeeId) {
          return item;
        }

        return {
          ...item,
          extraIngredients: item.extraIngredients
            .map((extra) =>
              extra.id === ingredientId
                ? {
                    ...extra,
                    quantity: extra.quantity - 1,
                  }
                : extra,
            )
            .filter((extra) => extra.quantity > 0),
        };
      }),
    );
  };

  // ==========================
  // Calculate Total Price
  // ==========================

  const calculateTotalPrice = (cartItem) => {
    const basePrice = 2;

    const defaultIngredientsPrice =
      cartItem.defaultIngredients?.reduce(
        (total, ingredient) => total + ingredient.data.price,
        0,
      ) || 0;

    const extraIngredientsPrice =
      cartItem.extraIngredients?.reduce(
        (total, ingredient) =>
          total + ingredient.data.price * ingredient.quantity,
        0,
      ) || 0;

    return (
      (basePrice + defaultIngredientsPrice + extraIngredientsPrice) *
      cartItem.quantity
    );
  };

  console.log("========== CURRENT CART ==========");
  console.log(cart);

  return (
    <CoffeeShopContext.Provider
      value={{
        cart,
        selectedCoffeeId,
        buyCoffee,
        removeCoffee,
        clearCart,
        addIngredient,
        removeIngredient,
        calculateTotalPrice,
      }}
    >
      {children}
    </CoffeeShopContext.Provider>
  );
};

export default CoffeeShopProvider;
