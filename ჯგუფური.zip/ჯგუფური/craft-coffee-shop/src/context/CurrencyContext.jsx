import { createContext, useEffect, useState } from "react";
import { convertCurrency } from "../services/currencyService";

export const CurrencyContext = createContext();

const CurrencyProvider = ({ children }) => {
  const [currency, setCurrency] = useState("GEL");
  const [exchangeRate, setExchangeRate] = useState(1);

  useEffect(() => {
    const loadRate = async () => {
      if (currency === "GEL") {
        setExchangeRate(1);
        return;
      }

      try {
        const result = await convertCurrency("GEL", "USD", 1);

        // API აბრუნებს:
        // amount -> 1 GEL რამდენი USD-ია
        // rate   -> 1 USD რამდენი GEL-ია
        setExchangeRate(Number(result.amount));
      } catch (error) {
        console.error("Currency rate error:", error);
        setExchangeRate(1);
      }
    };

    loadRate();
  }, [currency]);

  const toggleCurrency = () => {
    setCurrency((prev) => (prev === "GEL" ? "USD" : "GEL"));
  };

  // ლექციისთვის
  const convert = async (amount, fromCurrency = "GEL") => {
    if (fromCurrency === currency) {
      return {
        amount,
        rate: 1,
      };
    }

    return await convertCurrency(fromCurrency, currency, amount);
  };

  // UI-სთვის
  const formatPrice = (amount) => {
    const numericAmount = Number(amount);

    if (currency === "GEL") {
      return `${numericAmount.toFixed(2)} ₾`;
    }

    return `${(numericAmount * exchangeRate).toFixed(2)} $`;
  };

  return (
    <CurrencyContext.Provider
      value={{
        currency,
        exchangeRate,
        toggleCurrency,
        convert,
        formatPrice,
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
};

export default CurrencyProvider;
