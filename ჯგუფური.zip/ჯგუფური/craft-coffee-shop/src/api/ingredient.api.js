export const getIngredients = () => {};

export const getIngredientById = (id) => {};

export const createIngredient = (ingredient) => {};

export const updateIngredient = (ingredient) => {};

export const deleteIngredient = (id) => {};
