import Hero from "../components/Hero/Hero";
import CoffeeList from "../components/CoffeeList/CoffeeList";
import CartSidebar from "../components/Sidebar/CartSidebar";

const HomePage = () => {
  return (
    <>
      <Hero />
      <CoffeeList />
      <CartSidebar />
    </>
  );
};

export default HomePage;
