import { useContext, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";

import IngredientDetailsCard from "../components/IngredientDetails/IngredientDetailsCard";
import { IngredientContext } from "../context/IngredientContext";
import { CoffeeShopContext } from "../context/CoffeeShopContext";

const IngredientDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const { ingredients, fetchIngredients } = useContext(IngredientContext);

  const { addIngredient, removeIngredient } = useContext(CoffeeShopContext);

  useEffect(() => {
    if (ingredients.length === 0) {
      fetchIngredients();
    }
  }, [ingredients.length, fetchIngredients]);

  const ingredient = ingredients.find((item) => item.id === id);

  if (!ingredient) {
    return <h2>Loading...</h2>;
  }

  const handleAdd = () => {
    addIngredient(ingredient);
  };

  const handleRemove = () => {
    removeIngredient(ingredient.id);
  };

  const handleBack = () => {
    navigate("/ingredients");
  };

  return (
    <IngredientDetailsCard
      ingredient={ingredient}
      onAdd={handleAdd}
      onRemove={handleRemove}
      onBack={handleBack}
    />
  );
};

export default IngredientDetailsPage;
