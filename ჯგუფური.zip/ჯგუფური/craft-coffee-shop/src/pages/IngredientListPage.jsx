import { useContext, useEffect } from "react";

import IngredientCard from "../components/IngredientCard/IngredientCard";

import { IngredientContext } from "../context/IngredientContext";

import {
  IngredientSection,
  IngredientTitle,
  IngredientGrid,
} from "../styles/IngredientList.styles";

const IngredientListPage = () => {
  const { ingredients, fetchIngredients } = useContext(IngredientContext);

  useEffect(() => {
    fetchIngredients();
  }, []);

  return (
    <IngredientSection>
      <IngredientTitle>Discover Our Ingredients</IngredientTitle>

      {ingredients.length === 0 ? (
        <p>Loading...</p>
      ) : (
        <IngredientGrid>
          {ingredients.map((ingredient) => (
            <IngredientCard key={ingredient.id} ingredient={ingredient} />
          ))}
        </IngredientGrid>
      )}
    </IngredientSection>
  );
};

export default IngredientListPage;
