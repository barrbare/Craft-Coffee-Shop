import { useContext, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import Button from "../components/Button/Button";
import { CoffeeContext } from "../context/CoffeeContext";
import { IngredientContext } from "../context/IngredientContext";
import { CoffeeShopContext } from "../context/CoffeeShopContext";
import { CurrencyContext } from "../context/CurrencyContext";

import {
  PageContainer,
  Content,
  CoffeeImage,
  Info,
  CoffeeTitle,
  Text,
  IngredientsTitle,
  IngredientsList,
  ButtonsContainer,
} from "../components/CoffeeDetails/CoffeeDetails.styles";

const CoffeeDetailsPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const { coffees, fetchCoffees } = useContext(CoffeeContext);
  const { ingredients, fetchIngredients } = useContext(IngredientContext);
  const { buyCoffee } = useContext(CoffeeShopContext);
  const { currency, convert } = useContext(CurrencyContext);

  const [convertedPrices, setConvertedPrices] = useState({});

  useEffect(() => {
    if (coffees.length === 0) {
      fetchCoffees();
    }

    if (ingredients.length === 0) {
      fetchIngredients();
    }
  }, []);

  const coffee = coffees.find((item) => item.id === id);

  const coffeeIngredients =
    coffee && Array.isArray(coffee.data.ingredients)
      ? ingredients.filter((ingredient) =>
          coffee.data.ingredients.includes(ingredient.id),
        )
      : [];

  useEffect(() => {
    const loadPrices = async () => {
      if (currency === "GEL") {
        setConvertedPrices({});
        return;
      }

      const prices = {};

      for (const ingredient of coffeeIngredients) {
        const result = await convert(ingredient.data.price);

        prices[ingredient.id] = result.amount;
      }

      setConvertedPrices(prices);
    };

    if (coffeeIngredients.length > 0) {
      loadPrices();
    }
  }, [currency]);

  if (!coffee) {
    return <h2>Loading...</h2>;
  }

  return (
    <PageContainer>
      <Content>
        <CoffeeImage src={coffee.data.image} alt={coffee.data.title} />

        <Info>
          <CoffeeTitle>{coffee.data.title}</CoffeeTitle>

          <Text>
            <strong>Country:</strong> {coffee.data.country}
          </Text>

          <Text>
            <strong>Description:</strong> {coffee.data.description}
          </Text>

          <IngredientsTitle>Ingredients</IngredientsTitle>

          <IngredientsList>
            {coffeeIngredients.map((ingredient) => (
              <li key={ingredient.id}>
                {ingredient.data.name} —{" "}
                {currency === "GEL"
                  ? `${ingredient.data.price} ₾`
                  : `${Number(convertedPrices[ingredient.id] || 0).toFixed(
                      2,
                    )} $`}
              </li>
            ))}
          </IngredientsList>

          <Text>
            <strong>Caffeine:</strong> {coffee.data.caffeine ?? "Not specified"}
          </Text>

          <ButtonsContainer>
            <Button onClick={() => buyCoffee(coffee, coffeeIngredients)}>
              Buy
            </Button>

            <Button onClick={() => navigate("/coffees")}>
              Back to Coffees
            </Button>
          </ButtonsContainer>
        </Info>
      </Content>
    </PageContainer>
  );
};

export default CoffeeDetailsPage;
