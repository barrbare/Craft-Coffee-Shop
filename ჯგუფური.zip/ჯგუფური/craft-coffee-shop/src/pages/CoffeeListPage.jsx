import CoffeeList from "../components/CoffeeList/CoffeeList";

const CoffeeListPage = () => {
  return <CoffeeList />;
};

export default CoffeeListPage;
