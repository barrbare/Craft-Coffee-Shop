import styled from "styled-components";

export const MainContainer = styled("main")(({ $isHome }) => ({
  padding: $isHome ? "0" : "40px",

  width: "100%",

  overflowX: "hidden",

  backgroundColor: $isHome ? "transparent" : "#DBC2A8",
}));
