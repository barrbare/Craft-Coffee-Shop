import { useEffect, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";

import Header from "../components/Header/Header";
import Footer from "../components/Footer/Footer";
import CartSidebar from "../components/Sidebar/CartSidebar";
import ScrollToTop from "../components/ScrollToTop/ScrollToTop";

import { MainContainer } from "./MainLayout.styles";

const MainLayout = () => {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [showHeader, setShowHeader] = useState(true);

  const location = useLocation();

  useEffect(() => {
    if (location.pathname !== "/") {
      setShowHeader(true);
      return;
    }

    const handleScroll = () => {
      setShowHeader(window.scrollY > window.innerHeight - 100);
    };

    handleScroll();

    window.addEventListener("scroll", handleScroll);

    return () => window.removeEventListener("scroll", handleScroll);
  }, [location.pathname]);

  return (
    <>
      <ScrollToTop />

      <Header showHeader={showHeader} onCartClick={() => setIsCartOpen(true)} />

      <MainContainer $isHome={location.pathname === "/"}>
        <Outlet />
      </MainContainer>

      <CartSidebar isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />

      <Footer />
    </>
  );
};

export default MainLayout;
