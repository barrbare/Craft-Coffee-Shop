import styled from "styled-components";

export const IngredientSection = styled("section")({
  padding: "100px 20px 60px",

  background: "transparent",
});

export const IngredientTitle = styled("h2")({
  margin: "0 0 56px",

  textAlign: "center",

  fontSize: "48px",

  fontWeight: "700",

  lineHeight: "1.2",

  color: "#2f1b14",
});

export const IngredientGrid = styled("div")({
  display: "grid",

  gridTemplateColumns: "repeat(3, 320px)",

  gap: "40px",

  justifyContent: "center",
});
