import { Fragment } from "react";
import styles from "./Table.module.css";

const Table = ({ columns, data, actions }) => {
  return (
    <table className={styles.table}>
      <thead>
        <tr>
          {columns.map((column) => (
            <th key={column.key}>{column.title}</th>
          ))}
        </tr>
      </thead>

      <tbody>
        {data?.map((item) => (
          <Fragment key={item.id}>
            <tr>
              {columns.map((column) => (
                <td key={column.key}>{item[column.key]}</td>
              ))}
            </tr>

            {actions && (
              <tr>
                <td colSpan={columns.length} className={styles.actionsCell}>
                  <div className={styles.actions}>{actions(item)}</div>
                </td>
              </tr>
            )}
          </Fragment>
        ))}
      </tbody>
    </table>
  );
};

export default Table;
