import styles from "./AdminTable.module.css";

import Table from "../Table/Table";

const AdminTable = ({ title, createButton, columns, data, actions }) => {
  return (
    <div className={styles.wrapper}>
      <div className={styles.header}>
        <h2>{title}</h2>

        {createButton}
      </div>

      <Table columns={columns} data={data} actions={actions} />
    </div>
  );
};

export default AdminTable;
