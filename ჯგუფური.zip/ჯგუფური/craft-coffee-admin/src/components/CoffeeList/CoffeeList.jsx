import CoffeeCard from "../CoffeeCard/CoffeeCard";

import styles from "./CoffeeList.module.css";

const CoffeeList = ({ coffees, onDelete, onEdit }) => {
  return (
    <div className={styles.grid}>
      {coffees.map((coffee) => (
        <CoffeeCard
          key={coffee.id}
          coffee={coffee}
          onDelete={onDelete}
          onEdit={onEdit}
        />
      ))}
    </div>
  );
};

export default CoffeeList;
