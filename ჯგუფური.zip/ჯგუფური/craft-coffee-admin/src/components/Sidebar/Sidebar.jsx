import { NavLink } from "react-router-dom";

import styles from "./Sidebar.module.css";

const Sidebar = () => {
  return (
    <aside className={styles.sidebar}>
      <nav>
        <NavLink
          to="/coffees"
          className={({ isActive }) =>
            isActive ? styles.activeLink : styles.inactiveLink
          }
        >
          Coffees
        </NavLink>

        <NavLink
          to="/ingredients"
          className={({ isActive }) =>
            isActive ? styles.activeLink : styles.inactiveLink
          }
        >
          Ingredients
        </NavLink>
      </nav>
    </aside>
  );
};

export default Sidebar;
