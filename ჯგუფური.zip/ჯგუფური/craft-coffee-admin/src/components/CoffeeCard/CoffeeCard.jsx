import Button from "../Button/Button";

import styles from "./CoffeeCard.module.css";

const CoffeeCard = ({ coffee, onEdit, onDelete }) => {
  const ingredientCount = Array.isArray(coffee.data?.ingredients)
    ? coffee.data.ingredients.length
    : 0;

  return (
    <article
      className={styles.card}
      style={{
        backgroundImage: coffee.data?.image
          ? `url(${coffee.data.image})`
          : "linear-gradient(135deg, #7b5438 0%, #2f241f 100%)",
      }}
    >
      <div className={styles.overlay}>
        <div className={styles.content}>
          <h3 className={styles.title}>{coffee.data?.title}</h3>

          <div className={styles.info}>
            <p>
              <strong>Country</strong>
              <span>{coffee.data?.country}</span>
            </p>

            <p>
              <strong>Ingredients</strong>
              <span>
                {ingredientCount}{" "}
                {ingredientCount === 1 ? "ingredient" : "ingredients"}
              </span>
            </p>

            <p>
              <strong>Caffeine</strong>
              <span>{coffee.data?.caffeine}</span>
            </p>
          </div>

          <p className={styles.description}>{coffee.data?.description}</p>

          <div className={styles.actions}>
            <Button onClick={() => onEdit(coffee.id)}>Edit</Button>

            <Button onClick={() => onDelete(coffee.id)}>Delete</Button>
          </div>
        </div>
      </div>
    </article>
  );
};

export default CoffeeCard;
