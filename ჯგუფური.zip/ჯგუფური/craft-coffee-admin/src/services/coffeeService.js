import apiClient from "../api/apiClient";

export const getCoffees = () => {
  return apiClient("/api/v1/resource/coffees", {
    method: "GET",
  });
};

export const createCoffee = ({
  title,
  ingredients,
  description,
  image,
  country,
  caffeine,
}) => {
  return apiClient("/api/v1/resource/coffees", {
    method: "POST",
    body: JSON.stringify({
      data: [
        {
          title,
          ingredients,
          description,
          image,
          country,
          caffeine,
        },
      ],
    }),
  });
};

export const deleteCoffee = (id) => {
  return apiClient(`/api/v1/resource/coffees/${id}`, {
    method: "DELETE",
  });
};

export const updateCoffee = ({
  id,
  title,
  ingredients,
  description,
  image,
  country,
  caffeine,
}) => {
  return apiClient(`/api/v1/resource/coffees/${id}`, {
    method: "PUT",
    body: JSON.stringify({
      data: {
        title,
        ingredients,
        description,
        image,
        country,
        caffeine,
      },
    }),
  });
};
