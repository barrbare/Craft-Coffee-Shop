import apiClient from "../api/apiClient";

export const getIngredients = () => {
  return apiClient("/api/v1/resource/ingredients", {
    method: "GET",
  });
};

export const createIngredient = ({
  name,
  price,
  description,
  strength,
  flavor,
}) => {
  return apiClient("/api/v1/resource/ingredients", {
    method: "POST",
    body: JSON.stringify({
      data: [
        {
          name,
          price,
          description,
          strength,
          flavor,
        },
      ],
    }),
  });
};

export const deleteIngredient = (id) => {
  return apiClient(`/api/v1/resource/ingredients/${id}`, {
    method: "DELETE",
  });
};

export const updateIngredient = ({
  id,
  name,
  price,
  description,
  strength,
  flavor,
}) => {
  return apiClient(`/api/v1/resource/ingredients/${id}`, {
    method: "PUT",
    body: JSON.stringify({
      data: {
        name,
        price,
        description,
        strength,
        flavor,
      },
    }),
  });
};
