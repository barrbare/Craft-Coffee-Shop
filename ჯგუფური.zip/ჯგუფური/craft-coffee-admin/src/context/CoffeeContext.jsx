import { createContext, useState } from "react";

import {
  getCoffees,
  createCoffee,
  deleteCoffee as deleteCoffeeService,
  updateCoffee as updateCoffeeService,
} from "../services/coffeeService";

export const CoffeeContext = createContext();

const CoffeeProvider = ({ children }) => {
  const [coffees, setCoffees] = useState([]);

  const fetchCoffees = async () => {
    const response = await getCoffees();

    console.log("COFFEE RESPONSE:", response);

    setCoffees(response || []);
  };

  const addCoffee = async (coffee) => {
    const response = await createCoffee(coffee);

    setCoffees((prev) => [...prev, response]);
  };

  const deleteCoffee = async (id) => {
    await deleteCoffeeService(id);

    setCoffees((prev) => prev.filter((item) => item.id !== id));
  };

  const updateCoffee = async (coffee) => {
    await updateCoffeeService(coffee);

    await fetchCoffees();
  };

  return (
    <CoffeeContext.Provider
      value={{
        coffees,
        fetchCoffees,
        addCoffee,
        deleteCoffee,
        updateCoffee,
      }}
    >
      {children}
    </CoffeeContext.Provider>
  );
};

export default CoffeeProvider;
