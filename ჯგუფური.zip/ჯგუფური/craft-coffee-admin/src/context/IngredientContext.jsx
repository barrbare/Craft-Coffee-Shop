import { createContext, useState } from "react";

import {
  getIngredients,
  createIngredient,
  deleteIngredient as deleteIngredientService,
  updateIngredient as updateIngredientService,
} from "../services/ingredientService";

export const IngredientContext = createContext();

const IngredientProvider = ({ children }) => {
  const [ingredients, setIngredients] = useState([]);

  const fetchIngredients = async () => {
    const response = await getIngredients();

    console.log("INGREDIENT RESPONSE:", response);

    setIngredients(response || []);
  };

  const addIngredient = async (ingredient) => {
    const response = await createIngredient(ingredient);

    setIngredients((prev) => [...prev, response]);
  };

  const deleteIngredient = async (id) => {
    await deleteIngredientService(id);

    setIngredients((prev) => prev.filter((item) => item.id !== id));
  };

  const updateIngredient = async (ingredient) => {
    const response = await updateIngredientService(ingredient);

    setIngredients((prev) =>
      prev.map((item) => (item.id === ingredient.id ? response : item)),
    );
  };

  return (
    <IngredientContext.Provider
      value={{
        ingredients,
        fetchIngredients,
        addIngredient,
        deleteIngredient,
        updateIngredient,
      }}
    >
      {children}
    </IngredientContext.Provider>
  );
};

export default IngredientProvider;
