import { createBrowserRouter } from "react-router-dom";

import AdminLayout from "../layouts/AdminLayout/AdminLayout";

import CoffeeListPage from "../pages/CoffeeListPage/CoffeeListPage";
import CreateCoffeePage from "../pages/CreateCoffeePage/CreateCoffeePage";
import UpdateCoffeePage from "../pages/UpdateCoffeePage/UpdateCoffeePage";

import IngredientListPage from "../pages/IngredientListPage/IngredientListPage";
import CreateIngredientPage from "../pages/CreateIngredientPage/CreateIngredientPage";
import UpdateIngredientPage from "../pages/UpdateIngredientPage/UpdateIngredientPage";

const routes = createBrowserRouter([
  {
    path: "/",
    element: <AdminLayout />,
    children: [
      {
        path: "coffees",
        element: <CoffeeListPage />,
      },
      {
        path: "coffees/create",
        element: <CreateCoffeePage />,
      },
      {
        path: "coffees/update/:id",
        element: <UpdateCoffeePage />,
      },
      {
        path: "ingredients",
        element: <IngredientListPage />,
      },
      {
        path: "ingredients/create",
        element: <CreateIngredientPage />,
      },
      {
        path: "ingredients/update/:id",
        element: <UpdateIngredientPage />,
      },
    ],
  },
]);

export default routes;
