import { useContext, useState } from "react";
import { useNavigate } from "react-router-dom";

import Button from "../../components/Button/Button";
import Input from "../../components/Input/Input";
import { IngredientContext } from "../../context/IngredientContext";

const CreateIngredientPage = () => {
  const { addIngredient } = useContext(IngredientContext);

  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [strength, setStrength] = useState("");
  const [flavor, setFlavor] = useState("");

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (
      !name.trim() ||
      !price.trim() ||
      !description.trim() ||
      !strength.trim() ||
      !flavor.trim()
    ) {
      alert("Please fill in all fields.");
      return;
    }

    const numericPrice = Number(price);

    if (Number.isNaN(numericPrice)) {
      alert("Price must be a valid number.");
      return;
    }

    if (numericPrice <= 0) {
      alert("Price must be greater than 0.");
      return;
    }

    await addIngredient({
      name,
      price: numericPrice,
      description,
      strength,
      flavor,
    });

    navigate("/ingredients");
  };

  return (
    <div>
      <h2>Create Ingredient</h2>

      <form onSubmit={handleSubmit}>
        <Input
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="Name"
        />

        <Input
          type="number"
          value={price}
          onChange={(event) => setPrice(event.target.value)}
          placeholder="Price"
        />

        <Input
          value={description}
          onChange={(event) => setDescription(event.target.value)}
          placeholder="Description"
        />

        <Input
          value={strength}
          onChange={(event) => setStrength(event.target.value)}
          placeholder="Strength"
        />

        <Input
          value={flavor}
          onChange={(event) => setFlavor(event.target.value)}
          placeholder="Flavor"
        />

        <Button type="submit">Create</Button>
      </form>
    </div>
  );
};

export default CreateIngredientPage;
