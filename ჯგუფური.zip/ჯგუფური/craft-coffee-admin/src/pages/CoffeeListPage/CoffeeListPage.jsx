import { useContext, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

import Button from "../../components/Button/Button";
import CoffeeList from "../../components/CoffeeList/CoffeeList";
import { CoffeeContext } from "../../context/CoffeeContext";

import styles from "./CoffeeListPage.module.css";

const CoffeeListPage = () => {
  const navigate = useNavigate();

  const { coffees, fetchCoffees, deleteCoffee } = useContext(CoffeeContext);

  useEffect(() => {
    fetchCoffees();
  }, []);

  const handleEdit = (id) => {
    navigate(`/coffees/update/${id}`);
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <h1>Coffees</h1>

        <Link to="/coffees/create">
          <Button>Create Coffee</Button>
        </Link>
      </div>

      <CoffeeList
        coffees={[...coffees].reverse()}
        onEdit={handleEdit}
        onDelete={deleteCoffee}
      />
    </div>
  );
};

export default CoffeeListPage;
