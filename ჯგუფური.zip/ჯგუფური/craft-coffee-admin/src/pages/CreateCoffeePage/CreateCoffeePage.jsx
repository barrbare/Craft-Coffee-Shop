import { useContext, useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import Select from "react-select";

import Button from "../../components/Button/Button";
import Input from "../../components/Input/Input";

import { CoffeeContext } from "../../context/CoffeeContext";
import { IngredientContext } from "../../context/IngredientContext";

const CreateCoffeePage = () => {
  const { addCoffee } = useContext(CoffeeContext);

  const { ingredients, fetchIngredients } = useContext(IngredientContext);

  const navigate = useNavigate();

  const [title, setTitle] = useState("");
  const [selectedIngredients, setSelectedIngredients] = useState([]);
  const [description, setDescription] = useState("");

  const [image, setImage] = useState(
    "https://images.pexels.com/photos/997670/pexels-photo-997670.jpeg",
  );

  const [country, setCountry] = useState("");
  const [caffeine, setCaffeine] = useState("");

  useEffect(() => {
    fetchIngredients();
  }, []);

  const ingredientOptions = useMemo(() => {
    return ingredients.map((ingredient) => ({
      value: ingredient.id,
      label: ingredient.data.name,
    }));
  }, [ingredients]);

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (
      !title.trim() ||
      !description.trim() ||
      !image.trim() ||
      !country.trim() ||
      !caffeine.toString().trim()
    ) {
      alert("Please fill in all fields.");
      return;
    }

    if (selectedIngredients.length === 0) {
      alert("Please select at least one ingredient.");
      return;
    }

    const numericCaffeine = Number(caffeine);

    if (Number.isNaN(numericCaffeine)) {
      alert("Caffeine must be a valid number.");
      return;
    }

    if (numericCaffeine < 0) {
      alert("Caffeine cannot be negative.");
      return;
    }

    if (numericCaffeine > 200) {
      alert("Caffeine cannot be greater than 200.");
      return;
    }

    await addCoffee({
      title,
      ingredients: selectedIngredients.map((item) => item.value),
      description,
      image,
      country,
      caffeine: numericCaffeine,
    });

    navigate("/coffees");
  };

  return (
    <div>
      <h2>Create Coffee</h2>

      <form onSubmit={handleSubmit}>
        <Input
          value={title}
          onChange={(event) => setTitle(event.target.value)}
          placeholder="Title"
        />

        <div style={{ marginBottom: "20px" }}>
          <Select
            isMulti
            options={ingredientOptions}
            value={selectedIngredients}
            onChange={(selected) => setSelectedIngredients(selected || [])}
            placeholder="Select Ingredients..."
          />
        </div>

        <Input
          value={description}
          onChange={(event) => setDescription(event.target.value)}
          placeholder="Description"
        />

        <Input
          value={image}
          onChange={(event) => setImage(event.target.value)}
          placeholder="Image"
        />

        <Input
          value={country}
          onChange={(event) => setCountry(event.target.value)}
          placeholder="Country"
        />

        <Input
          value={caffeine}
          onChange={(event) => setCaffeine(event.target.value)}
          placeholder="Caffeine"
          type="number"
        />

        <Button type="submit">Create</Button>
      </form>
    </div>
  );
};

export default CreateCoffeePage;
