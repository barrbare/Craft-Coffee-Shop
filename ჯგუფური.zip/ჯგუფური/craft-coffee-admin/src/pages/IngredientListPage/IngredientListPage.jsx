import { useContext, useEffect } from "react";
import { Link } from "react-router-dom";

import Button from "../../components/Button/Button";
import AdminTable from "../../components/AdminTable/AdminTable";
import { IngredientContext } from "../../context/IngredientContext";

const IngredientListPage = () => {
  const { ingredients, deleteIngredient, fetchIngredients } =
    useContext(IngredientContext);

  useEffect(() => {
    fetchIngredients();
  }, []);

  const tableData = [...ingredients].reverse().map((item, index) => ({
    id: index + 1,
    originalId: item.id,
    name: item.data?.name,
    price: item.data?.price,
    description: item.data?.description,
    strength: item.data?.strength,
    flavor: item.data?.flavor,
  }));

  const columns = [
    {
      key: "id",
      title: "ID",
    },
    {
      key: "name",
      title: "Name",
    },
    {
      key: "price",
      title: "Price",
    },
    {
      key: "description",
      title: "Description",
    },
    {
      key: "strength",
      title: "Strength",
    },
    {
      key: "flavor",
      title: "Flavor",
    },
  ];

  const actions = (item) => (
    <>
      <Link to={`/ingredients/update/${item.originalId}`}>
        <Button variant="info">Edit</Button>
      </Link>

      <Button
        variant="danger"
        onClick={() => deleteIngredient(item.originalId)}
      >
        Delete
      </Button>
    </>
  );

  return (
    <AdminTable
      title="Ingredients"
      createButton={
        <Link to="/ingredients/create">
          <Button>Create Ingredient</Button>
        </Link>
      }
      columns={columns}
      data={tableData}
      actions={actions}
    />
  );
};

export default IngredientListPage;
