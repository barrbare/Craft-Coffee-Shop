import { useContext, useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

import Button from "../../components/Button/Button";
import Input from "../../components/Input/Input";
import { IngredientContext } from "../../context/IngredientContext";

const UpdateIngredientPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const { ingredients, updateIngredient, fetchIngredients } =
    useContext(IngredientContext);

  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [description, setDescription] = useState("");
  const [strength, setStrength] = useState("");
  const [flavor, setFlavor] = useState("");

  useEffect(() => {
    if (!ingredients.length) {
      fetchIngredients();
    }
  }, []);

  const ingredient = ingredients.find((item) => item.id === id);

  useEffect(() => {
    if (ingredient) {
      setName(ingredient.data.name);
      setPrice(ingredient.data.price);
      setDescription(ingredient.data.description);
      setStrength(ingredient.data.strength);
      setFlavor(ingredient.data.flavor);
    }
  }, [ingredient]);

  const handleSubmit = async (event) => {
    event.preventDefault();

    if (
      !name.trim() ||
      !price.toString().trim() ||
      !description.trim() ||
      !strength.trim() ||
      !flavor.trim()
    ) {
      alert("Please fill in all fields.");
      return;
    }

    const numericPrice = Number(price);

    if (Number.isNaN(numericPrice)) {
      alert("Price must be a valid number.");
      return;
    }

    if (numericPrice <= 0) {
      alert("Price must be greater than 0.");
      return;
    }

    await updateIngredient({
      id,
      name,
      price: numericPrice,
      description,
      strength,
      flavor,
    });

    await fetchIngredients();

    navigate("/ingredients");
  };

  return (
    <div>
      <h2>Update Ingredient</h2>

      <form onSubmit={handleSubmit}>
        <Input
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="Name"
        />

        <Input
          type="number"
          value={price}
          onChange={(event) => setPrice(event.target.value)}
          placeholder="Price"
        />

        <Input
          value={description}
          onChange={(event) => setDescription(event.target.value)}
          placeholder="Description"
        />

        <Input
          value={strength}
          onChange={(event) => setStrength(event.target.value)}
          placeholder="Strength"
        />

        <Input
          value={flavor}
          onChange={(event) => setFlavor(event.target.value)}
          placeholder="Flavor"
        />

        <Button type="submit">Update</Button>
      </form>
    </div>
  );
};

export default UpdateIngredientPage;
